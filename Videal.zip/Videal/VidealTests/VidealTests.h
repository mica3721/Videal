//
//  VidealTests.h
//  VidealTests
//
//  Created by Do Hyeong Kwon on 5/1/12.
//  Copyright (c) 2012 Stanford University. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface VidealTests : SenTestCase

@end
